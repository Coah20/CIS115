namespace FineForOverdueBooks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Parse the input values
            int numBooksCheckedOut = int.Parse(txtNumBooksCheckedOut.Text);
            int numDaysOverdue = int.Parse(txtNumDaysOverdue.Text);

            // Calculate the fine
            decimal fine = CalculateFine(numBooksCheckedOut, numDaysOverdue);

            // Display the fine
            MessageBox.Show($"The library fine is ${fine:F2}");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNumDaysOverdue_TextChanged(object sender, EventArgs e)
        {

        }

        private decimal CalculateFine(int numBooksCheckedOut, int numDaysOverdue)
        {
            decimal fine = 0;

            // Calculate the fine for the first seven days
            if (numDaysOverdue <= 7)
            {
                fine = numBooksCheckedOut * numDaysOverdue * 0.10m;
            }
            else
            {
                fine = numBooksCheckedOut * 7 * 0.10m; // Fine for the first seven days

                // Calculate the fine for each additional day
                fine += numBooksCheckedOut * (numDaysOverdue - 7) * 0.20m;
            }

            // Output the fine to the console
            Console.WriteLine($"The library fine is ${fine:F2}");

            return fine;
        }
    }
}

﻿namespace FineForOverdueBooks
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            txtNumBooksCheckedOut = new TextBox();
            btnCalculate = new Button();
            txtNumDaysOverdue = new TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(206, 175);
            label1.Name = "label1";
            label1.Size = new Size(140, 20);
            label1.TabIndex = 0;
            label1.Text = "Books Checked Out:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaptionText;
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(242, 224);
            label2.Name = "label2";
            label2.Size = new Size(104, 20);
            label2.TabIndex = 1;
            label2.Text = "Days Overdue:";
            // 
            // txtNumBooksCheckedOut
            // 
            txtNumBooksCheckedOut.BackColor = SystemColors.InfoText;
            txtNumBooksCheckedOut.ForeColor = SystemColors.Menu;
            txtNumBooksCheckedOut.Location = new Point(386, 175);
            txtNumBooksCheckedOut.Name = "txtNumBooksCheckedOut";
            txtNumBooksCheckedOut.Size = new Size(125, 27);
            txtNumBooksCheckedOut.TabIndex = 2;
            txtNumBooksCheckedOut.TextChanged += textBox1_TextChanged;
            // 
            // btnCalculate
            // 
            btnCalculate.BackColor = SystemColors.ActiveCaptionText;
            btnCalculate.ForeColor = SystemColors.Control;
            btnCalculate.Location = new Point(328, 292);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(94, 29);
            btnCalculate.TabIndex = 3;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = false;
            btnCalculate.Click += button1_Click;
            // 
            // txtNumDaysOverdue
            // 
            txtNumDaysOverdue.BackColor = SystemColors.InfoText;
            txtNumDaysOverdue.ForeColor = SystemColors.InactiveBorder;
            txtNumDaysOverdue.Location = new Point(386, 217);
            txtNumDaysOverdue.Name = "txtNumDaysOverdue";
            txtNumDaysOverdue.Size = new Size(125, 27);
            txtNumDaysOverdue.TabIndex = 5;
            txtNumDaysOverdue.TextChanged += txtNumDaysOverdue_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaptionText;
            label3.Font = new Font("Sitka Banner", 25.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.Control;
            label3.Location = new Point(172, 58);
            label3.Name = "label3";
            label3.Size = new Size(422, 62);
            label3.TabIndex = 6;
            label3.Text = "Fine For Overdue Books";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(txtNumDaysOverdue);
            Controls.Add(btnCalculate);
            Controls.Add(txtNumBooksCheckedOut);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtNumBooksCheckedOut;
        private Button btnCalculate;
        private TextBox txtNumDaysOverdue;
        private Label label3;
    }
}

﻿namespace CountVowelsModularized
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCount = new Button();
            textBoxInput = new TextBox();
            labelResult = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // buttonCount
            // 
            buttonCount.Location = new Point(305, 183);
            buttonCount.Name = "buttonCount";
            buttonCount.Size = new Size(94, 29);
            buttonCount.TabIndex = 0;
            buttonCount.Text = "Count ";
            buttonCount.UseVisualStyleBackColor = true;
            buttonCount.Click += buttonCount_Click;
            // 
            // textBoxInput
            // 
            textBoxInput.Location = new Point(346, 122);
            textBoxInput.Name = "textBoxInput";
            textBoxInput.Size = new Size(125, 27);
            textBoxInput.TabIndex = 1;
            // 
            // labelResult
            // 
            labelResult.AutoSize = true;
            labelResult.Font = new Font("SimSun", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelResult.Location = new Point(131, 248);
            labelResult.Name = "labelResult";
            labelResult.Size = new Size(268, 30);
            labelResult.TabIndex = 2;
            labelResult.Text = "Number of vowels:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("SimSun", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(118, 122);
            label1.Name = "label1";
            label1.Size = new Size(222, 28);
            label1.TabIndex = 3;
            label1.Text = "Enter a String:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PapayaWhip;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(labelResult);
            Controls.Add(textBoxInput);
            Controls.Add(buttonCount);
            Cursor = Cursors.Hand;
            Name = "Form1";
            Text = "Count Vowels Applcation";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCount;
        private TextBox textBoxInput;
        private Label labelResult;
        private Label label1;
    }
}

namespace CountVowelsModularized
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonCount_Click(object sender, EventArgs e)
        {
            string input = textBoxInput.Text;
            int vowelCount = CountVowels(input);
            labelResult.Text = $"Number of vowels: {vowelCount}";
        }

        private int CountVowels(string input)
        {
            int count = 0;
            foreach (char c in input.ToLower())
            {
                if ("aeiou".Contains(c))
                {
                    count++;
                }
            }
            return count;
        }
    }
}

using System.Data;

namespace InventoryManger
{
    public partial class Form1 : Form
    {
        DataTable inventory = new DataTable();

        public Form1()
        {
            InitializeComponent();

            // Setup the DataTable columns
            inventory.Columns.Add("SKU", typeof(string));
            inventory.Columns.Add("Name", typeof(string));
            inventory.Columns.Add("Category", typeof(string));
            inventory.Columns.Add("Price", typeof(decimal));
            inventory.Columns.Add("Description", typeof(string));
            inventory.Columns.Add("Quantity", typeof(int));

            // Bind the DataTable to the DataGridView
            inventoryGridView.DataSource = inventory;
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            // Clear all fields
            skuTextBox.Text = "";
            nameTextBox.Text = "";
            priceTextBox.Text = "";
            descriptionTextBox.Text = "";
            quantityTextBox.Text = "";
            categoryBox.SelectedIndex = -1;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            // Validate input
            if (!decimal.TryParse(priceTextBox.Text, out decimal price) || !int.TryParse(quantityTextBox.Text, out int quantity))
            {
                MessageBox.Show("Price and Quantity must be numeric values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Add a new row to the DataTable
            DataRow newRow = inventory.NewRow();
            newRow["SKU"] = skuTextBox.Text;
            newRow["Name"] = nameTextBox.Text;
            newRow["Category"] = categoryBox.SelectedItem;
            newRow["Price"] = price;
            newRow["Description"] = descriptionTextBox.Text;
            newRow["Quantity"] = quantity;
            inventory.Rows.Add(newRow);

            // Clear fields after save
            newButton_Click(sender, e);
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            // Delete the selected row
            if (inventoryGridView.CurrentRow != null)
            {
                inventory.Rows.RemoveAt(inventoryGridView.CurrentRow.Index);
            }
        }

        private void inventoryGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // Populate fields with data from the selected row
            if (inventoryGridView.CurrentRow != null)
            {
                skuTextBox.Text = inventory.Rows[inventoryGridView.CurrentRow.Index]["SKU"].ToString();
                nameTextBox.Text = inventory.Rows[inventoryGridView.CurrentRow.Index]["Name"].ToString();
                priceTextBox.Text = inventory.Rows[inventoryGridView.CurrentRow.Index]["Price"].ToString();
                descriptionTextBox.Text = inventory.Rows[inventoryGridView.CurrentRow.Index]["Description"].ToString();
                quantityTextBox.Text = inventory.Rows[inventoryGridView.CurrentRow.Index]["Quantity"].ToString();
                categoryBox.SelectedItem = inventory.Rows[inventoryGridView.CurrentRow.Index]["Category"];

            }
        }

    }

}



﻿namespace InventoryManger
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            priceTextBox = new TextBox();
            quantityTextBox = new TextBox();
            descriptionTextBox = new TextBox();
            inventoryGridView = new DataGridView();
            newButton = new Button();
            saveButton = new Button();
            deleteButton = new Button();
            skuTextBox = new TextBox();
            nameTextBox = new TextBox();
            skuLBL = new Label();
            nameLBL = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label3 = new Label();
            categoryBox = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)inventoryGridView).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Stencil", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(105, 5);
            label1.Name = "label1";
            label1.Size = new Size(776, 66);
            label1.TabIndex = 0;
            label1.Text = "Inventory Managment";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // priceTextBox
            // 
            priceTextBox.Location = new Point(12, 122);
            priceTextBox.Name = "priceTextBox";
            priceTextBox.Size = new Size(355, 27);
            priceTextBox.TabIndex = 1;
            // 
            // quantityTextBox
            // 
            quantityTextBox.Location = new Point(686, 122);
            quantityTextBox.Name = "quantityTextBox";
            quantityTextBox.Size = new Size(299, 27);
            quantityTextBox.TabIndex = 2;
            // 
            // descriptionTextBox
            // 
            descriptionTextBox.Location = new Point(373, 122);
            descriptionTextBox.Name = "descriptionTextBox";
            descriptionTextBox.Size = new Size(307, 27);
            descriptionTextBox.TabIndex = 3;
            // 
            // inventoryGridView
            // 
            inventoryGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            inventoryGridView.BackgroundColor = SystemColors.ButtonHighlight;
            inventoryGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            inventoryGridView.Location = new Point(3, 207);
            inventoryGridView.Name = "inventoryGridView";
            inventoryGridView.RowHeadersWidth = 51;
            inventoryGridView.Size = new Size(973, 349);
            inventoryGridView.TabIndex = 4;
            inventoryGridView.CellDoubleClick += inventoryGridView_CellDoubleClick;
            // 
            // newButton
            // 
            newButton.Location = new Point(12, 155);
            newButton.Name = "newButton";
            newButton.Size = new Size(355, 46);
            newButton.TabIndex = 5;
            newButton.Text = "New";
            newButton.UseVisualStyleBackColor = true;
            newButton.Click += newButton_Click;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(373, 155);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(307, 46);
            saveButton.TabIndex = 6;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += saveButton_Click;
            // 
            // deleteButton
            // 
            deleteButton.Location = new Point(686, 155);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(299, 46);
            deleteButton.TabIndex = 7;
            deleteButton.Text = "Delete";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click;
            // 
            // skuTextBox
            // 
            skuTextBox.Location = new Point(12, 61);
            skuTextBox.Name = "skuTextBox";
            skuTextBox.Size = new Size(355, 27);
            skuTextBox.TabIndex = 8;
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(373, 61);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(307, 27);
            nameTextBox.TabIndex = 9;
            // 
            // skuLBL
            // 
            skuLBL.AutoSize = true;
            skuLBL.Location = new Point(12, 37);
            skuLBL.Name = "skuLBL";
            skuLBL.Size = new Size(39, 20);
            skuLBL.TabIndex = 11;
            skuLBL.Text = "SKU:";
            // 
            // nameLBL
            // 
            nameLBL.AutoSize = true;
            nameLBL.Location = new Point(373, 37);
            nameLBL.Name = "nameLBL";
            nameLBL.Size = new Size(52, 20);
            nameLBL.TabIndex = 12;
            nameLBL.Text = "Name:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(686, 37);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 13;
            label4.Text = "Category:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 99);
            label5.Name = "label5";
            label5.Size = new Size(44, 20);
            label5.TabIndex = 14;
            label5.Text = "Price:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(373, 99);
            label6.Name = "label6";
            label6.Size = new Size(88, 20);
            label6.TabIndex = 15;
            label6.Text = "Description:";
            // 
            // label7
            // 
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(100, 23);
            label7.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(686, 99);
            label3.Name = "label3";
            label3.Size = new Size(68, 20);
            label3.TabIndex = 17;
            label3.Text = "Quantity:";
            // 
            // categoryBox
            // 
            categoryBox.FormattingEnabled = true;
            categoryBox.Items.AddRange(new object[] { "Beads", "Thread", "Fabric", "Basket Supplies" });
            categoryBox.Location = new Point(686, 61);
            categoryBox.Name = "categoryBox";
            categoryBox.Size = new Size(299, 28);
            categoryBox.TabIndex = 18;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1008, 549);
            Controls.Add(categoryBox);
            Controls.Add(label3);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(nameLBL);
            Controls.Add(skuLBL);
            Controls.Add(nameTextBox);
            Controls.Add(skuTextBox);
            Controls.Add(deleteButton);
            Controls.Add(saveButton);
            Controls.Add(newButton);
            Controls.Add(inventoryGridView);
            Controls.Add(descriptionTextBox);
            Controls.Add(quantityTextBox);
            Controls.Add(priceTextBox);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)inventoryGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox priceTextBox;
        private TextBox quantityTextBox;
        private TextBox descriptionTextBox;
        private DataGridView inventoryGridView;
        private Button newButton;
        private Button saveButton;
        private Button deleteButton;
        private TextBox skuTextBox;
        private TextBox nameTextBox;
        private Label skuLBL;
        private Label nameLBL;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label3;
        private ComboBox categoryBox;
    }
}

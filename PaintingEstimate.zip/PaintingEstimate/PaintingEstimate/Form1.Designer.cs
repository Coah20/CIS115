﻿namespace PaintingEstimate
{
    partial class PaintingEsitmate
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PaintingEsitmate));
            textBoxLength = new TextBox();
            textBoxWidth = new TextBox();
            buttonCalculate = new Button();
            label1 = new Label();
            label2 = new Label();
            labelResult = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // textBoxLength
            // 
            textBoxLength.Location = new Point(381, 90);
            textBoxLength.Name = "textBoxLength";
            textBoxLength.Size = new Size(125, 27);
            textBoxLength.TabIndex = 0;
            // 
            // textBoxWidth
            // 
            textBoxWidth.Location = new Point(381, 147);
            textBoxWidth.Name = "textBoxWidth";
            textBoxWidth.Size = new Size(125, 27);
            textBoxWidth.TabIndex = 1;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(370, 217);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(94, 29);
            buttonCalculate.TabIndex = 2;
            buttonCalculate.Text = "Calculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(285, 90);
            label1.Name = "label1";
            label1.Size = new Size(90, 31);
            label1.TabIndex = 3;
            label1.Text = "Length:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(294, 143);
            label2.Name = "label2";
            label2.Size = new Size(81, 31);
            label2.TabIndex = 4;
            label2.Text = "Width:";
            // 
            // labelResult
            // 
            labelResult.AutoSize = true;
            labelResult.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelResult.Location = new Point(381, 303);
            labelResult.Name = "labelResult";
            labelResult.Size = new Size(77, 38);
            labelResult.TabIndex = 5;
            labelResult.Text = "$$$$";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(170, 303);
            label4.Name = "label4";
            label4.Size = new Size(205, 38);
            label4.TabIndex = 7;
            label4.Text = "Estimated Cost:";
            // 
            // PaintingEsitmate
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(labelResult);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonCalculate);
            Controls.Add(textBoxWidth);
            Controls.Add(textBoxLength);
            Name = "PaintingEsitmate";
            Text = "Painting Esitmate";
            Load += PaintingEsitmate_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxLength;
        private TextBox textBoxWidth;
        private Button buttonCalculate;
        private Label label1;
        private Label label2;
        private Label labelResult;
        private Label label4;
    }
}

namespace PaintingEstimate
{
    public partial class PaintingEsitmate : Form
    {
        public PaintingEsitmate()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(textBoxLength.Text, out double length) || !double.TryParse(textBoxWidth.Text, out double width))
            {
                MessageBox.Show("Please enter valid numeric values for length and width.");
                return;
            }

            double price = CalculatePrice(length, width);
            labelResult.Text = $" ${price}";
        }

        private double CalculatePrice(double length, double width)
        {
            const double CostPerSquareFoot = 6.0;
            const double CeilingHeight = 9.0;
            double totalWallArea = 2 * (length + width) * CeilingHeight;
            double price = totalWallArea * CostPerSquareFoot;
            return price;

        }

        private void PaintingEsitmate_Load(object sender, EventArgs e)
        {

        }

        private void PaintingEsitmate_Load_1(object sender, EventArgs e)
        {

        }
    }
}
